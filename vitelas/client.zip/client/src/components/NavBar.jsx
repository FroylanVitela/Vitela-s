export default function NavBar() {
  return (
    <nav>
      <a href="#bienvenida">Bienvenida</a>
      <a href="#catalogo">Catálogo</a>
      <a href="#contacto">Contacto</a>
    </nav>
  );
}