import './ProductCard.css';

export default function ProductCard({ title, description, image }) {
  return (
    <div className="producto">
      <img src={image} alt={title} />
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      <button className="btn">Personalizar</button>
    </div>
  );
}