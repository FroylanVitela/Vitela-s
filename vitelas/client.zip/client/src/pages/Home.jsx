import HeroSlider from '../components/HeroSlider.jsx';

export default function Home() {
  return <HeroSlider />;
}