import { useEffect, useState } from 'react';
import ProductCard from '../components/ProductCard.jsx';
import api from '../services/api.js';
import './Catalog.css';

export default function Catalog() {
  const [variants, setVariants] = useState([]);
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => {
    api.get('/products').then(({ data }) => {
      const items = data.flatMap((p) =>
        p.variants.map((v) => ({ ...v, productSlug: p.slug, productName: p.name }))
      );
      setVariants(items);
    });
  }, []);

  const categories = Array.from(new Set(variants.map((v) => v.productName)));

  const filtered = variants.filter((v) => {
    const matchCategory = category === 'all' || v.productName === category;
    const matchSearch = v.name.toLowerCase().includes(search.toLowerCase());
    return matchCategory && matchSearch;
  });

  return (
    <section className="catalog">
      <aside className="filters">
        <input
          type="text"
          placeholder="Buscar productos..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <ul>
          <li onClick={() => setCategory('all')} className={category === 'all' ? 'active' : ''}>
            Todos
          </li>
          {categories.map((c) => (
            <li key={c} onClick={() => setCategory(c)} className={category === c ? 'active' : ''}>
              {c}
            </li>
          ))}
        </ul>
      </aside>
      <div className="grid">
        {filtered.map((v) => (
          <ProductCard key={v.sku} image={`https://via.placeholder.com/200?text=${v.name}`} title={v.name} />
        ))}
      </div>
    </section>
  );
}